using UnityEngine;

[CreateAssetMenu(menuName = "Scriptables/Values/Float")]
public class FloatAsset : TAsset<float>
{
}

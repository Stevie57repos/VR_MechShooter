using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct EnemyFlockRequest 
{
    public int UnitID;

}

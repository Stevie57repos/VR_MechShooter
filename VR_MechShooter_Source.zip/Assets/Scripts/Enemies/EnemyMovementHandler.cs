using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovementHandler : MonoBehaviour
{
    public void HandleMovement(Transform target, List<EnemyController> enemiesInWave)
    {
        throw new System.NotImplementedException();
    }
}

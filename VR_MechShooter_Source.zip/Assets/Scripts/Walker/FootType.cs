﻿public enum FootType { left, right};
